package com.carrito_api_spring_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarritoApiSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarritoApiSpringBootApplication.class, args);
	}

}
