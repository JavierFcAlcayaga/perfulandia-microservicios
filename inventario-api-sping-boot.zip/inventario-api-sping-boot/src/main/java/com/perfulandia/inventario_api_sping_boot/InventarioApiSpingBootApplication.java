package com.perfulandia.inventario_api_sping_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventarioApiSpingBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventarioApiSpingBootApplication.class, args);
	}

}
