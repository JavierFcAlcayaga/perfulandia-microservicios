package com.perfulandia.inventario_api_sping_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventarioApiSpingBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
