package com.perfulandia.productos_api_spring_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductosApiSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
